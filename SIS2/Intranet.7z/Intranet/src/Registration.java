import java.util.*;

public class Registration {

	public static Vector<Course> availableCourses = new Vector<Course>();
	
}
