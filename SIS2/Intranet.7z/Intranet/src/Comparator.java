
public interface Comparator<E> {
	
	 int compare(E a, E b);

}
