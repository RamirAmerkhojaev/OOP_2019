
public enum Rooms {

	ROUND_HALL,
	COWORKING,
	BUSINESS_HALL,
}
